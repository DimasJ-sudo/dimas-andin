<?php
session_start();
require_once __DIR__ . '/includes/koneksi.php';
require_once __DIR__ . '/includes/helpers.php';
$pageTitle = 'Lacak Laporan';

$uid = trim($_GET['id'] ?? '');
$report = null; $logs = [];
if ($uid !== '') {
    $stmt = $pdo->prepare("SELECT * FROM reports WHERE report_uid = ?");
    $stmt->execute([$uid]);
    $report = $stmt->fetch();
    if ($report) {
        $stmt2 = $pdo->prepare("SELECT * FROM report_logs WHERE report_id = ? ORDER BY created_at ASC");
        $stmt2->execute([$report['id']]);
        $logs = $stmt2->fetchAll();
    }
}
include __DIR__ . '/includes/header.php';
?>
<div class="max-w-2xl mx-auto">
  <div class="flex items-center gap-3 mb-5">
    <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 text-white flex items-center justify-center shadow-md shadow-blue-200">
      <svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4-4"/></svg>
    </div>
    <div>
      <h1 class="text-2xl font-extrabold text-emerald-900">Lacak Laporan</h1>
      <p class="text-sm text-gray-600">Masukkan ID unik laporanmu (contoh: SK-0824-01).</p>
    </div>
  </div>
  <form method="get" class="flex gap-2 mb-6">
    <input type="text" name="id" value="<?= e($uid) ?>" placeholder="SK-XXXX-XX" required class="flex-1 border-gray-300 rounded-xl px-4 py-3 border focus:ring-emerald-500 focus:border-emerald-500 font-mono text-lg">
    <button class="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white px-6 py-3 rounded-xl font-bold shadow-md shadow-emerald-200">Lacak</button>
  </form>

  <?php if ($uid && !$report): ?>
    <div class="bg-red-50 border border-red-300 text-red-700 p-4 rounded-xl flex items-center gap-2">
      <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M15 9l-6 6M9 9l6 6"/></svg>
      ID Laporan tidak ditemukan.
    </div>
  <?php endif; ?>

  <?php if ($report): ?>
    <div class="bg-white border border-emerald-100 rounded-2xl p-5 mb-4 shadow-sm">
      <div class="flex items-center gap-2 flex-wrap mb-2">
        <span class="text-xs font-mono text-gray-500"><?= e($report['report_uid']) ?></span>
        <span class="text-xs px-2 py-0.5 bg-emerald-50 text-emerald-700 rounded-full"><?= e($report['category']) ?></span>
        <?= urgency_badge($report['urgency']) ?>
        <?= status_badge($report['status']) ?>
      </div>
      <p class="text-sm whitespace-pre-line text-gray-800"><?= e($report['description']) ?></p>
      <?php if ($report['admin_response']): ?>
        <div class="mt-3 bg-emerald-50 border-l-4 border-emerald-500 p-3 text-sm text-emerald-900 rounded">
          <b>Respon Admin:</b><br><?= nl2br(e($report['admin_response'])) ?>
        </div>
      <?php endif; ?>
    </div>

    <h3 class="font-bold text-emerald-900 mb-3 flex items-center gap-2">
      <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
      Riwayat Status
    </h3>
    <ol class="relative border-l-2 border-emerald-200 ml-3 space-y-5">
      <?php foreach ($logs as $lg): ?>
        <li class="ml-5">
          <span class="absolute -left-2.5 w-5 h-5 bg-gradient-to-br from-emerald-400 to-teal-500 rounded-full border-4 border-white badge-glow"></span>
          <div class="bg-white border border-emerald-100 rounded-xl p-3 shadow-sm">
            <div class="flex items-center gap-2 mb-1">
              <?= status_badge($lg['status_change']) ?>
              <span class="text-xs text-gray-400"><?= e(date('d M Y H:i', strtotime($lg['created_at']))) ?></span>
            </div>
            <?php if ($lg['note']): ?><div class="text-sm text-gray-700"><?= nl2br(e($lg['note'])) ?></div><?php endif; ?>
          </div>
        </li>
      <?php endforeach; ?>
    </ol>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
