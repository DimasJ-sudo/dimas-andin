<?php
session_start();
require_once __DIR__ . '/includes/koneksi.php';
require_once __DIR__ . '/includes/helpers.php';
$pageTitle = 'Beranda';

$total = (int)$pdo->query("SELECT COUNT(*) FROM reports")->fetchColumn();
$selesai = (int)$pdo->query("SELECT COUNT(*) FROM reports WHERE status='Selesai'")->fetchColumn();
$proses = (int)$pdo->query("SELECT COUNT(*) FROM reports WHERE status='Diproses'")->fetchColumn();

include __DIR__ . '/includes/header.php';
?>
<section class="relative overflow-hidden rounded-3xl p-8 sm:p-12 shadow-xl bg-gradient-to-br from-emerald-600 via-emerald-700 to-teal-800 text-white">
  <div class="absolute inset-0 grid-pattern opacity-20"></div>
  <div class="absolute -top-16 -right-16 w-72 h-72 bg-teal-400/30 rounded-full blur-3xl"></div>
  <div class="absolute -bottom-20 -left-10 w-72 h-72 bg-emerald-300/20 rounded-full blur-3xl"></div>

  <div class="relative">
    <span class="inline-flex items-center gap-2 bg-white/15 backdrop-blur border border-white/20 text-emerald-50 text-xs font-semibold px-3 py-1.5 rounded-full mb-4">
      <svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="4"/></svg>
      Aman · Anonim · Transparan
    </span>
    <h1 class="text-3xl sm:text-5xl font-extrabold mb-4 leading-tight">Suaramu<br>Didengar.</h1>
    <p class="text-emerald-50/90 max-w-xl mb-7 text-base sm:text-lg">Kotak Suara adalah kotak aspirasi digital sekolahmu — sampaikan masalah, pantau progresnya, dan lihat perubahan nyata terjadi.</p>
    <div class="flex flex-wrap gap-3">
      <a href="lapor.php" class="bg-white text-emerald-700 font-bold px-6 py-3 rounded-xl hover:scale-[1.03] transition shadow-lg inline-flex items-center gap-2">
        <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M12 19V5M5 12l7-7 7 7"/></svg>
        Kirim Laporan
      </a>
      <a href="lacak.php" class="bg-white/10 hover:bg-white/20 border border-white/30 text-white font-semibold px-6 py-3 rounded-xl inline-flex items-center gap-2">
        <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4-4"/></svg>
        Lacak Laporan
      </a>
    </div>
  </div>
</section>

<section class="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6">
  <div class="relative bg-white rounded-2xl p-5 border border-emerald-100 card-hover overflow-hidden">
    <div class="absolute top-0 right-0 w-24 h-24 bg-emerald-100 rounded-full -mr-10 -mt-10 opacity-60"></div>
    <div class="relative flex items-center gap-3">
      <div class="w-11 h-11 rounded-xl bg-emerald-500/10 text-emerald-600 flex items-center justify-center">
        <svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 11l3 3 8-8M20 12v6a2 2 0 01-2 2H6a2 2 0 01-2-2V6a2 2 0 012-2h9"/></svg>
      </div>
      <div>
        <div class="text-xs text-gray-500">Total Laporan</div>
        <div class="text-3xl font-extrabold text-emerald-700"><?= $total ?></div>
      </div>
    </div>
  </div>
  <div class="relative bg-white rounded-2xl p-5 border border-emerald-100 card-hover overflow-hidden">
    <div class="absolute top-0 right-0 w-24 h-24 bg-blue-100 rounded-full -mr-10 -mt-10 opacity-60"></div>
    <div class="relative flex items-center gap-3">
      <div class="w-11 h-11 rounded-xl bg-blue-500/10 text-blue-600 flex items-center justify-center">
        <svg class="w-6 h-6 animate-spin" style="animation-duration:6s" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 11-6.2-8.55"/></svg>
      </div>
      <div>
        <div class="text-xs text-gray-500">Sedang Diproses</div>
        <div class="text-3xl font-extrabold text-blue-600"><?= $proses ?></div>
      </div>
    </div>
  </div>
  <div class="relative bg-white rounded-2xl p-5 border border-emerald-100 card-hover overflow-hidden">
    <div class="absolute top-0 right-0 w-24 h-24 bg-teal-100 rounded-full -mr-10 -mt-10 opacity-60"></div>
    <div class="relative flex items-center gap-3">
      <div class="w-11 h-11 rounded-xl bg-teal-500/10 text-teal-600 flex items-center justify-center">
        <svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg>
      </div>
      <div>
        <div class="text-xs text-gray-500">Telah Selesai</div>
        <div class="text-3xl font-extrabold text-teal-600"><?= $selesai ?></div>
      </div>
    </div>
  </div>
</section>

<section class="mt-10">
  <div class="flex items-end justify-between mb-4">
    <h2 class="text-xl font-bold text-emerald-900">Cara Kerja</h2>
    <span class="text-xs text-gray-500">3 langkah mudah</span>
  </div>
  <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
    <a href="lapor.php" class="bg-white rounded-2xl p-6 border border-emerald-100 card-hover">
      <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-500 text-white flex items-center justify-center mb-4 shadow-md shadow-emerald-200">
        <svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9M16.5 3.5a2.12 2.12 0 113 3L7 19l-4 1 1-4 12.5-12.5z"/></svg>
      </div>
      <h3 class="font-bold mb-1 text-gray-900">1. Kirim Laporan</h3>
      <p class="text-sm text-gray-600">Tulis aspirasi atau masalah yang kamu rasakan. Bisa anonim.</p>
    </a>
    <a href="lacak.php" class="bg-white rounded-2xl p-6 border border-emerald-100 card-hover">
      <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-500 text-white flex items-center justify-center mb-4 shadow-md shadow-blue-200">
        <svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4-4"/></svg>
      </div>
      <h3 class="font-bold mb-1 text-gray-900">2. Lacak Progress</h3>
      <p class="text-sm text-gray-600">Gunakan ID unik laporanmu untuk memantau tindak lanjut admin.</p>
    </a>
    <a href="publik.php" class="bg-white rounded-2xl p-6 border border-emerald-100 card-hover">
      <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500 to-orange-500 text-white flex items-center justify-center mb-4 shadow-md shadow-amber-200">
        <svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M7 11V7a5 5 0 0110 0v4M5 11h14l-1 10H6L5 11z"/></svg>
      </div>
      <h3 class="font-bold mb-1 text-gray-900">3. Dukung Aspirasi</h3>
      <p class="text-sm text-gray-600">Upvote masalah yang juga kamu rasakan untuk memperkuat suaranya.</p>
    </a>
  </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>
